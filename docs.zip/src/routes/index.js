import { Router } from 'express';
import transactionsRouter from './transactions.js';
import authRouter from './auth.js';
import categoriesRouter from './categories.js';
<<<<<<< HEAD
=======
import currentUserRouter from './currentUser.js';
>>>>>>> main

const router = Router();

router.use('/transactions', transactionsRouter);
router.use('/auth', authRouter);
router.use('/categories', categoriesRouter);
<<<<<<< HEAD
=======
router.use('/user', currentUserRouter);
>>>>>>> main

export default router;
